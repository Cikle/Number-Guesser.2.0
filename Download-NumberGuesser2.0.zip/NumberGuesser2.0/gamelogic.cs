﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace NumberGuesser2._0
{
    public class GameLogic
    {
        private List<int> usedNumbers = new List<int>();
        private int targetNumber;

        public void StartNewGame()
        {
            Random random = new Random();
            targetNumber = random.Next(1, 101);
            usedNumbers.Clear();
        }

        public bool CheckGuess(int guess, out string feedbackMessage)
        {
            feedbackMessage = "";

            if (guess < 1 || guess > 100)
            {
                feedbackMessage = "Please enter a number between 1 and 100.";
                return false;
            }

            usedNumbers.Add(guess);

            if (guess < targetNumber)
            {
                feedbackMessage = $"The number {guess} is too small";
            }
            else if (guess > targetNumber)
            {
                feedbackMessage = $"The number {guess} is too big";
            }
            else
            {
                feedbackMessage = "Congrats! You have guessed the number";
                return true;
            }

            return false;
        }

        public List<int> GetUsedNumbers()
        {
            return usedNumbers;
        }

        public void ClearUsedNumbers()
        {
            usedNumbers.Clear();
        }
    }
}
