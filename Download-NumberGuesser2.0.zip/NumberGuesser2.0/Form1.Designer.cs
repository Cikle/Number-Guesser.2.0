﻿namespace NumberGuesser2._0
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Play1 = new System.Windows.Forms.Button();
            this.Player1 = new System.Windows.Forms.GroupBox();
            this.send = new System.Windows.Forms.Button();
            this.numberisbiggerorsmaller = new System.Windows.Forms.Label();
            this.exitGame = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.usednumbers = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.InputNumbers = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.endGame = new System.Windows.Forms.Button();
            this.newGame = new System.Windows.Forms.Button();
            this.winnerscreen = new System.Windows.Forms.GroupBox();
            this.triescounter = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonExitToMenu = new System.Windows.Forms.Button();
            this.ReplayButton = new System.Windows.Forms.Button();
            this.Player1.SuspendLayout();
            this.winnerscreen.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Akira Expanded", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(355, 151);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(288, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome To Number-Guesser 2.0";
            // 
            // Play1
            // 
            this.Play1.Font = new System.Drawing.Font("Akira Expanded", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Play1.Location = new System.Drawing.Point(412, 242);
            this.Play1.Name = "Play1";
            this.Play1.Size = new System.Drawing.Size(177, 30);
            this.Play1.TabIndex = 1;
            this.Play1.Text = "Play";
            this.Play1.UseVisualStyleBackColor = true;
            this.Play1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Player1
            // 
            this.Player1.Controls.Add(this.send);
            this.Player1.Controls.Add(this.numberisbiggerorsmaller);
            this.Player1.Controls.Add(this.exitGame);
            this.Player1.Controls.Add(this.label6);
            this.Player1.Controls.Add(this.usednumbers);
            this.Player1.Controls.Add(this.label5);
            this.Player1.Controls.Add(this.InputNumbers);
            this.Player1.Controls.Add(this.label4);
            this.Player1.Controls.Add(this.endGame);
            this.Player1.Controls.Add(this.newGame);
            this.Player1.Location = new System.Drawing.Point(12, 12);
            this.Player1.Name = "Player1";
            this.Player1.Size = new System.Drawing.Size(960, 537);
            this.Player1.TabIndex = 4;
            this.Player1.TabStop = false;
            this.Player1.Enter += new System.EventHandler(this.Player1_Enter);
            // 
            // send
            // 
            this.send.Font = new System.Drawing.Font("Akira Expanded", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.send.Location = new System.Drawing.Point(421, 193);
            this.send.Name = "send";
            this.send.Size = new System.Drawing.Size(148, 21);
            this.send.TabIndex = 17;
            this.send.Text = "send";
            this.send.UseVisualStyleBackColor = true;
            this.send.Click += new System.EventHandler(this.send_Click);
            // 
            // numberisbiggerorsmaller
            // 
            this.numberisbiggerorsmaller.AutoSize = true;
            this.numberisbiggerorsmaller.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberisbiggerorsmaller.Location = new System.Drawing.Point(419, 239);
            this.numberisbiggerorsmaller.Name = "numberisbiggerorsmaller";
            this.numberisbiggerorsmaller.Size = new System.Drawing.Size(122, 12);
            this.numberisbiggerorsmaller.TabIndex = 16;
            this.numberisbiggerorsmaller.Text = "Please Put a number ";
            // 
            // exitGame
            // 
            this.exitGame.Font = new System.Drawing.Font("Akira Expanded", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitGame.Location = new System.Drawing.Point(6, 19);
            this.exitGame.Name = "exitGame";
            this.exitGame.Size = new System.Drawing.Size(70, 25);
            this.exitGame.TabIndex = 15;
            this.exitGame.Text = "Exit";
            this.exitGame.UseVisualStyleBackColor = true;
            this.exitGame.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Akira Expanded", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(738, 129);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 12);
            this.label6.TabIndex = 12;
            this.label6.Text = "Used NUmbers";
            // 
            // usednumbers
            // 
            this.usednumbers.Location = new System.Drawing.Point(740, 144);
            this.usednumbers.Name = "usednumbers";
            this.usednumbers.Size = new System.Drawing.Size(193, 242);
            this.usednumbers.TabIndex = 11;
            this.usednumbers.Text = "";
            this.usednumbers.TextChanged += new System.EventHandler(this.usednumbers_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Akira Expanded", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(428, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 12);
            this.label5.TabIndex = 10;
            this.label5.Text = "Input Number";
            // 
            // InputNumbers
            // 
            this.InputNumbers.Location = new System.Drawing.Point(421, 163);
            this.InputNumbers.Name = "InputNumbers";
            this.InputNumbers.Size = new System.Drawing.Size(148, 20);
            this.InputNumbers.TabIndex = 9;
            this.InputNumbers.TextChanged += new System.EventHandler(this.InputNumbers_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Akira Expanded", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(419, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(150, 12);
            this.label4.TabIndex = 8;
            this.label4.Text = "Number Guesser";
            // 
            // endGame
            // 
            this.endGame.Font = new System.Drawing.Font("Akira Expanded", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.endGame.Location = new System.Drawing.Point(6, 123);
            this.endGame.Name = "endGame";
            this.endGame.Size = new System.Drawing.Size(133, 25);
            this.endGame.TabIndex = 21;
            this.endGame.Text = "End Game";
            this.endGame.UseVisualStyleBackColor = true;
            this.endGame.Click += new System.EventHandler(this.endgame_Click);
            // 
            // newGame
            // 
            this.newGame.Font = new System.Drawing.Font("Akira Expanded", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newGame.Location = new System.Drawing.Point(6, 70);
            this.newGame.Name = "newGame";
            this.newGame.Size = new System.Drawing.Size(133, 25);
            this.newGame.TabIndex = 22;
            this.newGame.Text = "New Game";
            this.newGame.UseVisualStyleBackColor = true;
            this.newGame.Click += new System.EventHandler(this.button3_Click);
            // 
            // winnerscreen
            // 
            this.winnerscreen.Controls.Add(this.triescounter);
            this.winnerscreen.Controls.Add(this.label7);
            this.winnerscreen.Controls.Add(this.label3);
            this.winnerscreen.Controls.Add(this.buttonExitToMenu);
            this.winnerscreen.Controls.Add(this.ReplayButton);
            this.winnerscreen.Location = new System.Drawing.Point(12, 12);
            this.winnerscreen.Name = "winnerscreen";
            this.winnerscreen.Size = new System.Drawing.Size(975, 552);
            this.winnerscreen.TabIndex = 20;
            this.winnerscreen.TabStop = false;
            // 
            // triescounter
            // 
            this.triescounter.AutoSize = true;
            this.triescounter.Location = new System.Drawing.Point(446, 363);
            this.triescounter.Name = "triescounter";
            this.triescounter.Size = new System.Drawing.Size(82, 13);
            this.triescounter.TabIndex = 24;
            this.triescounter.Text = "Number of Tries";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Akira Expanded", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(447, 239);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 12);
            this.label7.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Akira Expanded", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(353, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(261, 39);
            this.label3.TabIndex = 22;
            this.label3.Text = "YOU WON";
            // 
            // buttonExitToMenu
            // 
            this.buttonExitToMenu.Font = new System.Drawing.Font("Akira Expanded", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExitToMenu.Location = new System.Drawing.Point(360, 286);
            this.buttonExitToMenu.Name = "buttonExitToMenu";
            this.buttonExitToMenu.Size = new System.Drawing.Size(253, 48);
            this.buttonExitToMenu.TabIndex = 21;
            this.buttonExitToMenu.Text = "Exit to main screen";
            this.buttonExitToMenu.UseVisualStyleBackColor = true;
            this.buttonExitToMenu.Click += new System.EventHandler(this.button2_Click);
            // 
            // ReplayButton
            // 
            this.ReplayButton.Font = new System.Drawing.Font("Akira Expanded", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReplayButton.Location = new System.Drawing.Point(357, 221);
            this.ReplayButton.Name = "ReplayButton";
            this.ReplayButton.Size = new System.Drawing.Size(256, 48);
            this.ReplayButton.TabIndex = 20;
            this.ReplayButton.Text = "Replay";
            this.ReplayButton.UseVisualStyleBackColor = true;
            this.ReplayButton.Click += new System.EventHandler(this.ReplayButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 561);
            this.Controls.Add(this.winnerscreen);
            this.Controls.Add(this.Player1);
            this.Controls.Add(this.Play1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Player1.ResumeLayout(false);
            this.Player1.PerformLayout();
            this.winnerscreen.ResumeLayout(false);
            this.winnerscreen.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Play1;
        private System.Windows.Forms.GroupBox Player1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox InputNumbers;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox usednumbers;
        private System.Windows.Forms.Button exitGame;
        private System.Windows.Forms.Label numberisbiggerorsmaller;
        private System.Windows.Forms.Button send;
        private System.Windows.Forms.GroupBox winnerscreen;
        private System.Windows.Forms.Button buttonExitToMenu;
        private System.Windows.Forms.Button ReplayButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button endGame;
        private System.Windows.Forms.Button newGame;
        private System.Windows.Forms.Label numberOfTries;
        private System.Windows.Forms.Label triescounter;
    }
}

