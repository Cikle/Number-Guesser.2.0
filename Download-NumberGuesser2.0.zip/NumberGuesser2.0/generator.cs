﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace NumberGuesser2._0
{
    public class Generator
    {
        private Random random = new Random();

        public int GenerateRandomNumber()
        {
            return random.Next(1, 101);
        }
    }
}

